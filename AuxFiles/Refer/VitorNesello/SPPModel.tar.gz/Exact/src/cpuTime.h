
//Output.h

#ifndef __main__cpuTime__
#define __main__cpuTime__

#include <cstdlib>
#include <math.h>
#include <iomanip>

using namespace std;



double cpuTime ();




#endif 
